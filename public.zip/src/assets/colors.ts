export const backgroundColor = '#cceeff';
export const rightPanelColor = '#cceeff';
export const leftPnaleColor ='#cceeff';
export const chatBoxColor = 'white';
export const serviceDescriptionCards = 'white';
// src/PatentChart.js
import React from "react";
import { VictoryBar, VictoryChart, VictoryAxis, VictoryTheme, VictoryTooltip } from "victory";
import { sampleData } from "../hooks/mock";


const processData = (data :any) => {
  const result: any = {};

  data.forEach((patent: any) => {
    const year = patent.publication_date.split("-")[0];
    if (result[year]) {
      result[year]++;
    } else {
      result[year] = 1;
    }
  });

  return Object.keys(result).map((year) => ({
    year,
    count: result[year],
  }));
};

const PatentChart = () => {
  const data = processData(sampleData);

  return (
    <div style={{ width: "100%", maxWidth: "400px", margin: "0 auto", display: 'flex', flexDirection: 'column', alignItems: "center",justifyContent: 'center'}}>
        <h4>Patent Publication timeline </h4>
      <VictoryChart
        theme={VictoryTheme.material}
        domainPadding={20}
      >
        <VictoryAxis
          tickValues={data.map((d) => d.year)}
          tickFormat={data.map((d) => d.year)}
        />
        <VictoryAxis
          dependentAxis
          tickFormat={(x) => (`${x}`)}
        />
        <VictoryBar
          data={data}
          x="year"
          y="count"
          labels={({ datum }) => `${datum.count} patents`}
          labelComponent={<VictoryTooltip />}
          style={{ data: { fill: "#B0D9ED" } }}
        />
      </VictoryChart>
    </div>
  );
};

export default PatentChart;

// src/CategoryChart.js
import React from "react";
import { VictoryBar, VictoryChart, VictoryAxis, VictoryTheme, VictoryTooltip } from "victory";
import { sampleData } from "../hooks/mock";

// Function to generate random colors
const getRandomColor = () => {
  const letters = "0123456789ABCDEF";
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

// Processing data and assigning a color to each category
const processCategoryData = (data: any) => {
  const categoryCount: any = {};

  data.forEach((patent:any) => {
    const category = patent.index;
    if (categoryCount[category]) {
      categoryCount[category].count++;
    } else {
      categoryCount[category] = { count: 1, color: getRandomColor() };
    }
  });

  return Object.keys(categoryCount).map((category) => ({
    category,
    count: categoryCount[category].count,
    color: categoryCount[category].color,
  }));
};

const CategoryChart = () => {
  const data = processCategoryData(sampleData);

  return (
    <div style={{ width: "100%", maxWidth: "400px", margin: "0 auto",display: 'flex', flexDirection: 'column', alignItems: "center",justifyContent: 'center' }}>
      <h4>Technology Focus Distribution</h4>
      <VictoryChart theme={VictoryTheme.material} domainPadding={20}>
        <VictoryAxis tickValues={data.map((d) => d.category)} tickFormat={data.map((d) => d.category)} />
        <VictoryAxis dependentAxis tickFormat={(x) => `${x}`} />
        <VictoryBar
          data={data}
          x="category"
          y="count"
          labels={({ datum }) => `${datum.count} patents`}
          labelComponent={<VictoryTooltip />}
          style={{
            data: {
              fill: ({ datum }) => datum.color, // Use the pre-assigned color for each bar
            },
          }}
        />
      </VictoryChart>
    </div>
  );
};

export default CategoryChart;
